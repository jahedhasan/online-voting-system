-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 25, 2023 at 01:01 PM
-- Server version: 10.5.20-MariaDB-cll-lve
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medipjuo_voting`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `candidate_id` int(11) NOT NULL,
  `position` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `year_level` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `img` varchar(100) NOT NULL,
  `symbol` varchar(191) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`candidate_id`, `position`, `firstname`, `lastname`, `year_level`, `gender`, `img`, `symbol`) VALUES
(2, 'Vice President', 'Nancy', 'Mace', '', 'Female', 'upload/_Nancy_Mace_.png', 'upload/vicetrump.jpg'),
(3, 'General Secretary', 'Sandy ', 'Su', '', 'Female', 'upload/generalsandy.jpeg', 'upload/logo3.png'),
(4, 'Assistant General Secretary', 'Mike', 'Pom', '', 'Male', 'upload/mike.jpeg', 'upload/logo4.png'),
(5, 'President', 'Joe', 'Baiden', '', 'Male', 'upload/biden.jpg', 'upload/baidenlogo.jpg'),
(6, 'President', 'Donald', ' Trump', '', 'Male', 'upload/trump.jpeg', 'upload/trumplogo.jpeg'),
(7, 'Vice President', 'Kamala', 'Harris', '', 'Female', 'upload/kamlahaies.jpeg', 'upload/vicebaiden.png'),
(8, 'General Secretary', 'Antony ', 'Blinken', '', 'Male', 'upload/antony.jpg', 'upload/logo2.png'),
(9, 'Secretary, Science and Technology', 'Rania ', 'Mir', '', 'Female', 'upload/img.jpg', 'upload/logo1.png'),
(10, 'Secretary, Literature', 'Sanna ', 'Marin', '', 'Female', 'upload/Sanna-Marin-PM-of-Finland-.jpg', 'upload/logo5.png'),
(11, 'Secretary, International Affiars', 'Whitmer', 'Esar', '', 'Female', 'upload/Gretchen-Whitmer.jpg', 'upload/vicebaiden.png'),
(12, 'Secretary, International Affiars', 'Hans', 'Mark', '', 'Male', 'upload/Politicians.jpg', 'upload/jjj.jpg'),
(13, 'Assistant General Secretary', 'Tulsi ', 'Gabbard', '', 'Female', 'upload/lsdy.jpeg', 'upload/ages.png'),
(15, 'Member', 'Eva', 'Kaili', '', 'Female', 'upload/Eva-Kaili.jpeg.jpg', 'upload/download.png'),
(16, 'Secretary, Culture', 'Hina', 'Rabbani', '', 'Female', 'upload/image7.png', 'upload/imas.png'),
(17, 'Secretary, Culture', 'Harek ', 'Son', '', 'Male', 'upload/istoc.jpg', 'upload/2_big2-768x591.png'),
(18, 'Member', 'Jon ', 'Kate', '', 'Male', 'upload/istockphoto-.jpg', 'upload/pigeon.png'),
(19, 'Secretary, Science and Technology', 'Naris', 'Gricsa', '', 'Female', 'upload/Gretchen-Whitmer.jpg', 'upload/im (1).jpeg'),
(20, 'Secretary, Literature', 'Raja ', 'Jayapal', '', 'Male', 'upload/raja.jpg', 'upload/es.png');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `firstname`, `lastname`) VALUES
(1, 'admin', 'admin', 'Jahed', 'Hasan');

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE `voters` (
  `voters_id` int(11) NOT NULL,
  `id_number` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `pnumber` varchar(100) DEFAULT NULL,
  `year_level` varchar(100) NOT NULL,
  `dob` text DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `status` varchar(100) NOT NULL,
  `account` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`voters_id`, `id_number`, `password`, `firstname`, `lastname`, `email`, `pnumber`, `year_level`, `dob`, `gender`, `address`, `status`, `account`) VALUES
(11, 12345, 'jahed', 'jahed hasan', 'bhuiyan', 'jahed@mail.com', '01829284769', '3rd Year', '16/06/1998', 'Male', 'feni, ctg, bangladesh', 'Voted', 'Active'),
(10, 1234, '1234', 'sanir', 'ahmed', 'sanir@gmail.com', '01829284769', '2nd Year', '09/09/1999', 'Male', 'Nilpamary', 'Voted', 'Active'),
(9, 123, '123', 'jahed', 'hasan', 'jh@gmail.com', '01829284769', '1st Year', '10/12/1998', 'Male', 'feni sadar', 'Voted', 'Active'),
(12, 112233, '112233', 'jahed ', 'TEST', 'jahed.duet@gmail.com', '01829284769', '', '16/06/1998', 'Male', 'JAHED TESTING', 'Unvoted', 'Active'),
(13, 204001, '204001', 'Sanir', 'Ahmed', 'ksanir508@gmail.com', '01568105246', '', '31/12/2000', 'Male', 'Joydevpur', 'Unvoted', 'Active'),
(14, 123123123, 'jahed123', 'J', 'Hasan', 'j@gmail.com', '01920471930', '', '29/12/1995', 'Male', 'Gazipur Sadar', 'Unvoted', 'Active'),
(15, 204074, '204074', 'Rakib', 'Hasan', 'rakib@gmail.com', '01544442454', '', '10/06/1998', 'Male', 'Gazipur', 'Voted', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `vote_id` int(255) NOT NULL,
  `candidate_id` varchar(255) NOT NULL,
  `voters_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`vote_id`, `candidate_id`, `voters_id`) VALUES
(1, '5', '9'),
(2, '2', '9'),
(3, '8', '9'),
(4, '', '9'),
(5, '', '9'),
(6, '', '9'),
(7, '', '9'),
(8, '', '9'),
(9, '', '9'),
(10, '', '10'),
(11, '', '10'),
(12, '', '10'),
(13, '', '10'),
(14, '9', '10'),
(15, '', '10'),
(16, '', '10'),
(17, '', '10'),
(18, '', '10'),
(19, '10', '11'),
(20, '2', '11'),
(21, '3', '11'),
(22, '13', '11'),
(23, '9', '11'),
(24, '12', '11'),
(25, '', '11'),
(26, '', '11'),
(27, '', '11'),
(28, '10', '15'),
(29, '2', '15'),
(30, '8', '15'),
(31, '13', '15'),
(32, '9', '15'),
(33, '11', '15'),
(34, '', '15'),
(35, '16', '15'),
(36, '15', '15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`candidate_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `voters`
--
ALTER TABLE `voters`
  ADD PRIMARY KEY (`voters_id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`vote_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `candidate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `voters`
--
ALTER TABLE `voters`
  MODIFY `voters_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `vote_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
