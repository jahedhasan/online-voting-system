
<?php include ('head.php');?>
<body>
<?php
	// function passFunc($len, $set = "")
	// 	{
	// 		$gen = "";
	// 		for($i = 0; $i < $len; $i++)
	// 			{
	// 				$set = str_shuffle($set);
	// 				$gen.= $set[0]; 
	// 			}
	// 		return $gen;
	// 	} 
		
?>

    <div id="wrapper" style="    margin: 22px 380px 66px;">
		<h1>Online Voting System</h1>
        <!-- Page Content -->
        <div id="" >
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">Registration</h3>
                </div>
				<div class = "well col-lg-6">
					<div class="panel panel-green">
                        <div class="panel-heading">
                            Please Enter the Detail Needed Below
                        </div>
                        <div class="panel-body">
                         <form method = "post" enctype = "multipart/form-data">	
											<div class="form-group">
												<label>ID Number</label>
												<input class ="form-control" type = "text" name = "id_number" placeholder = "ID number" required="true">
													
											</div>
											
											<div class="form-group">
											<?php 
													// $change =  passFunc(8, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890');
											?>	
												<label>Password</label>
													<input class="form-control" type ="password" name = "password" required="true">
													<!-- <input class="form-control"  type = "text" name = "password" id = "pass" required="true" readonly="readonly" />
													<input type = "button" value = "Generate" onclick = "document.getElementById('pass').value = '<?php echo $change?>'"> -->
											</div>
											
											<div class="form-group">
												<label>Firstname</label>
													<input class="form-control" type ="text" name = "firstname" placeholder="Firstname" required="true">
											</div>
											<div class="form-group">
												<label>Lastname</label>
													<input class="form-control"  type = "text" name = "lastname" placeholder="Lastname" required="true">
											</div>
											<div class="form-group">
												<label>Email</label>
													<input class="form-control"  type = "mail" name = "email" placeholder="Please enter valid mail" required="true">
											</div>
											<div class="form-group">
												<label>Phone</label>
													<input class="form-control" name = "pnumber" type="text" maxlength="11" pattern="\d{11}" placeholder="Please enter exactly 11 digits" />
											</div>
									
											<div class="form-group">
												<label>Date of Birth</label><span style="margin-left:4px" class="fa fa-calendar" id="fa-1"></span>
													<input class="form-control" type="text" id="datepicker" name = "dob"  placeholder="Click to show the datepicker (dd/mm/yyyy)" required="true">
											</div>
											<div class="form-group">
												<label for="gender">Gender</label>

												<div class="form-check">
												<input class="form-check-input" type="radio" name="gender" value="Male" id="flexRadioDefault1" >
												<label class="form-check-label" for="flexRadioDefault1">
													Male
												</label>
												</div>
												<div class="form-check">
												<input class="form-check-input" type="radio" name="gender" value="Female" id="flexRadioDefault2" >
												<label class="form-check-label" for="flexRadioDefault2">
													Female
												</label>
												</div>
											</div>
											
											<div class="form-group">
												<label for="address">Address</label>
												<textarea class="form-control" id="address" name="address" rows="3"></textarea>
											</div>
																												
											 	 <button name = "save" type="submit" class="btn btn-primary">Save Data</button>
												 
						  				 </div>
                                       
										
										</form>
								
							<?php 
								require 'dbcon.php';
								
								if (isset($_POST['save'])){
									$firstname=$_POST['firstname'];
									$lastname=$_POST['lastname'];
									$id_number=$_POST['id_number'];
									
									$password = $_POST['password'];
                                    $address=$_POST['address'];
									$gender = $_POST['gender'];
									$dob = $_POST['dob'];
									$email= $_POST['email'];
									$pnumber = $_POST['pnumber'];

									$query = $conn->query("SELECT * FROM voters WHERE id_number='$id_number'") or die (mysql_error());
									$count = $query->fetch_array();

									if ($count  > 0){ 
									?>
										<script>
											alert("ID Number Already Exist");
										</script>
									<?php
										}
										else{
										$conn->query("insert into voters(id_number, password, firstname,lastname,email,pnumber,dob,gender,address,status) VALUES('$id_number', '$password','$firstname','$lastname','$email','$pnumber','$dob', '$gender' ,'$address','Unvoted')");
									?>
									<script>
										alert('Voters Successfully Save');
									</script>
							<?php
									}
								} 
							?>
						  
						
						</div>
						</form>
                    </div>
                </div>
				<div>
				
					<a class="btn btn-primary" href="../index.php">Voter login</a>
					<a class="btn btn-primary" href="../admin/candidate.php">Admin</a>
				</div>
            </div>
			
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
<?php include ('script.php');?>
</body>

</html>

