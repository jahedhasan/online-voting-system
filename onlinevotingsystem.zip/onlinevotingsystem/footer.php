
<footer style="font-size:20px;margin-bottom:30px" class="bg-light text-center text-lg-start">
  <!-- Copyright -->
  <div class="text-center p-3">
    © 2023 Copyright:
    <a class="text-dark" href="#">Online Voting System.</a>
  </div>
  <!-- Copyright -->
</footer>