<?php include ('head.php');?>
<body>
    <div class="container">
        <div class="row">
		
		<center><h3>Online Voting System</h3></center>
        <center>
            ​<picture>
                <img src="./images/banner.jpg" width="350" height="150" alt="...">
            </picture>
        </center>
         
            <div class="col-md-6 col-md-offset-3" style="margin-top: -70px;">
			
                <div class="login-panel panel panel-default">
				
                    <div class="panel-heading">
                        <center><h3 class="panel-title"> Log In</h3></center>
                    </div>
                    <div class="panel-body">
                        <form role="form" method = "post" enctype = "multipart/form-data">
                            <fieldset>
							
                                <div class="form-group">
									<label for = "username" >ID No.</label>
										<input class="form-control" placeholder="Please Enter Voter's ID Number" name="idno" type="text" required = "required" autofocus>
                                </div>
								
                                <div class="form-group">
									<label for = "username" >Password</label>
										<input class="form-control" placeholder="Password" name="password" type="password" required = "required">
                                </div>
                             
                              
                                <button class="btn btn-lg btn-success btn-block " name = "login">Login</button>
                                <hr/>
                            </fieldset>

                                <?php include ('login_query.php');?>
                                <hr/>
                                <a href="./admin/index.php" class="btn btn-sm btn-primary  " >Admin Login</a>
                                <a href="./register/index.php" class="btn btn-sm btn-info " >Registration</a>

                        </form>
                        <hr/>
                        <h4><b>Note:</b> </h4>
                        <ol>
                            <li>১৮ বছর এর নিচে কেউ ভোট দিতে পারবেন না।</li>
                            <li> একজন ভোটার ১ বারই ভোটই দিতে পারবেন ২য় বার ভোট দিতে পারবেন না। </li>
                            <li> আপনার পছন্দের প্রার্থীকে ভোট দিয়েছেন কিনা ভালোভাবে দেখে নিন। </li>
                            <li>সৎ ও যোগ্য প্রার্থীকে ভোট দিন।</li>
                            <li>নির্বাচনের আচরণ বিধি মেনে চলুন।</li>
                            <li>সুস্থ, সুন্দর বাংলাদেশ গড়তে আপনার মূল্যবান ভোট প্রয়োগ করুন।</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <?php include ('footer.php');?>
    </div>

  <?php include ('script.php');?>

</body>

</html>
